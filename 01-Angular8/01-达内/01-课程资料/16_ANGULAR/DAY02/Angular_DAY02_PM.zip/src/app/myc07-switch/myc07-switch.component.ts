import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc07-switch',
  templateUrl: './myc07-switch.component.html',
  styleUrls: ['./myc07-switch.component.css']
})
export class Myc07SwitchComponent implements OnInit {
  //userLevel = ''
  userLevel = 'normal'
  //userLevel = 'vip'
  //userLevel = 'blackgold'

  constructor() { }

  ngOnInit() {
  }

}
