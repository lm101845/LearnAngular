import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc03-ngif',
  templateUrl: './myc03-ngif.component.html',
  styleUrls: ['./myc03-ngif.component.css']
})
export class Myc03NgifComponent implements OnInit {
  //isPayingUser = true     //当前用户是否为“付费用户”
  isPayingUser = false

  constructor() { }

  ngOnInit() {
  }

}
