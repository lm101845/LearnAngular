import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appXuYaoQiangDiao]'
})
export class XuYaoQiangDiaoDirective {
  //age: number = 20
  //构造方法
  constructor( el: ElementRef ) { 
    console.log('需要强调指令实例化一次')
    el.nativeElement.style.background = '#fcc'
    el.nativeElement.style.padding = '10px'
    el.nativeElement.style.color = '#833'
  }

}
