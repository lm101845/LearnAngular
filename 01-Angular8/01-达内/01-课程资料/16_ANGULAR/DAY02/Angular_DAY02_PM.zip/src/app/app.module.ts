import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Myc01BuyCountComponent } from './myc01-buy-count/myc01-buy-count.component';
import { Myc02NgforComponent } from './myc02-ngfor/myc02-ngfor.component';
import { Myc03NgifComponent } from './myc03-ngif/myc03-ngif.component';
import { Myc04NgifComponent } from './myc04-ngif/myc04-ngif.component';
import { Myc05NgifComponent } from './myc05-ngif/myc05-ngif.component';
import { Myc06StyleComponent } from './myc06-style/myc06-style.component';
import { Myc07SwitchComponent } from './myc07-switch/myc07-switch.component';
import { Myc08NgmodelComponent } from './myc08-ngmodel/myc08-ngmodel.component';
//FormsModule中提供了ngModel指令
import { FormsModule } from '@angular/forms';
import { XuYaoQiangDiaoDirective } from './xu-yao-qiang-diao.directive'

@NgModule({
  declarations: [
    AppComponent,
    Myc01BuyCountComponent,
    Myc02NgforComponent,
    Myc03NgifComponent,
    Myc04NgifComponent,
    Myc05NgifComponent,
    Myc06StyleComponent,
    Myc07SwitchComponent,
    Myc08NgmodelComponent,
    XuYaoQiangDiaoDirective
  ],
  imports: [
    //导入浏览器模块，其中导出了CommonModule(包含ngFor/ngIf....不包含ngModel!)
    BrowserModule,
    //导入FormsModule中提供了ngModel指令
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
