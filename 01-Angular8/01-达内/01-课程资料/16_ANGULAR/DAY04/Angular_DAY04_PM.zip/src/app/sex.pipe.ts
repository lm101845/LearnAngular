import { PipeTransform } from '@angular/core';

/*
interface PipeTransform{
  transform();
}
*/
export class SexPipe implements PipeTransform {
  transform(val){
    return val
  }
}