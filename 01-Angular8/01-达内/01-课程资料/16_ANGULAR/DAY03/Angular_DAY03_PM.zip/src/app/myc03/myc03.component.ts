import { Component, OnInit } from '@angular/core';
import { LogService } from '../log.service';

@Component({
  selector: 'app-myc03',
  templateUrl: './myc03.component.html',
  styleUrls: ['./myc03.component.css']
})
export class Myc03Component implements OnInit {
  //组件：王思聪——服务使用者，必须声明依赖
  log = null  
  constructor(log:LogService){   //声明依赖
    //console.log('王思聪诞生了...')
    //console.log(log)
    this.log = log
  }
  doAdd(){
    console.log('正在执行数据库添加...')
    let action = '添加了新的商品：xxxx'
    this.log.doLog(action)
  }
  doDelete(){
    console.log('正在执行数据库删除...')
    let action = '删除了已有商品：xxxx'
    this.log.doLog(action)
  }

  ngOnInit() {
  }

}
