import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-myc04',
  templateUrl: './myc04.component.html',
  styleUrls: ['./myc04.component.css']
})
export class Myc04Component implements OnInit {
  http = null
  constructor(http:HttpClient) { //声明依赖一个服务对象
    this.http = http
  }
  loadProduct(){  //加载学子商城的商品
    let url = 'http://www.codeboy.com/data/product/list.php?pno=2'
    //使用注入进来的HttpClient实例发起异步请求
    this.http.get(url).subscribe((res)=>{
      console.log('得到了订阅的异步响应消息')
      console.log(res)
    })
  }

  ngOnInit() {
  }

}
