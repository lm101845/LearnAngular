import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'zzmm3'
})
export class Zzmm3Pipe {

  transform(val, format='short') {
    if(format=='short'){
        if(val===10)return '党员'
        else if(val===20)return '团员'
        else if(val===30)return '群众'
    }else if(format=='long'){
        if(val===10)return '中国共产党党员'
        else if(val===20)return '中国青团团员'
        else if(val===30)return '中国人民群众'
    }
  }

}
