import { Injectable } from '@angular/core';

//所有的服务对象都是“可被注入的”
@Injectable({
  providedIn: 'root'   //王健林-服务提供者
})
export class LogService{   //法拉利
  //执行日志记录功能
  doLog(action){
    let uname = 'admin4'
    let time = new Date().getTime()
    console.log(`管理员：${uname} 时间：${time} 动作：${action}`)
  }
}