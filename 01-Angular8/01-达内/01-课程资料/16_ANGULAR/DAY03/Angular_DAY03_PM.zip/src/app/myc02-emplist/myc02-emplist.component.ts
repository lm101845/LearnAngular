import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02-emplist',
  templateUrl: './myc02-emplist.component.html',
  styleUrls: ['./myc02-emplist.component.css']
})
export class Myc02EmplistComponent implements OnInit {
  //empList = []
  empList = [
    {eid:101, ename:'liang liang', salary:5000.12345, birthday:0, sex:1, zzmm:10},
    {eid:102, ename:'Ran Ran', salary:1234567, birthday:1000, sex:0, zzmm:20},
    {eid:103, ename:'donG dOng', salary:5000.12789, birthday:1000*3600*24, sex:1, zzmm:30},
    {eid:104, ename:'tAO TAo', salary:800, birthday:1000*3600*24*365, sex:0, zzmm:20},
  ]

  doDelete(index){
    //从数据中删除指定的下标
    this.empList.splice(index, 1)
  }


  constructor() { }

  ngOnInit() {
  }

}
