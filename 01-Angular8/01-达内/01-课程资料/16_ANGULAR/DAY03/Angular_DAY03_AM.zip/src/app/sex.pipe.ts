import { Pipe } from '@angular/core';

@Pipe({
  name: 'sex'   //过滤器/管道名
})
export class SexPipe {
  //管道到执行过滤任务的是一个固定的函数
  // transform(val){   //转换/变形
  //   if(val==1){
  //     return '男'
  //   }else if(val==0) {
  //     return '女'
  //   }else {
  //     return '未知'
  //   }
  // }
  transform(val, lang='zh'){   //转换/变形
    if(lang=='zh'){
        if(val==1){
          return '男'
        }else if(val==0) {
          return '女'
        }else {
          return '未知'
        }
    }else if(lang=='en'){
        if(val==1){
          return 'Male'
        }else if(val==0) {
          return 'Female'
        }else {
          return 'Unknown'
        }
    }
  }
}