import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Myc01TodolistComponent } from './myc01-todolist/myc01-todolist.component';
import { FormsModule } from '@angular/forms';
import { Myc02EmplistComponent } from './myc02-emplist/myc02-emplist.component'
import { SexPipe } from './sex.pipe';

@NgModule({
  declarations: [
    AppComponent,
    Myc01TodolistComponent,
    Myc02EmplistComponent,
    SexPipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
