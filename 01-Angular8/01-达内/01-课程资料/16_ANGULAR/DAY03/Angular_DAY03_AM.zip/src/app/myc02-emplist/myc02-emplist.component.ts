import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc02-emplist',
  templateUrl: './myc02-emplist.component.html',
  styleUrls: ['./myc02-emplist.component.css']
})
export class Myc02EmplistComponent implements OnInit {
  //empList = []
  empList = [
    {eid:101, ename:'亮亮', salary:5000, birthday:0, sex:1, zzmm:10},
    {eid:102, ename:'然然', salary:6000, birthday:0, sex:0, zzmm:20},
    {eid:103, ename:'东东', salary:7000, birthday:0, sex:1, zzmm:30},
    {eid:104, ename:'涛涛', salary:8000, birthday:0, sex:0, zzmm:20},
  ]

  doDelete(index){
    //从数据中删除指定的下标
    this.empList.splice(index, 1)
  }


  constructor() { }

  ngOnInit() {
  }

}
