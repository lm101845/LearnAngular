import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myc01-todolist',
  templateUrl: './myc01-todolist.component.html',
  styleUrls: ['./myc01-todolist.component.css']
})
export class Myc01TodolistComponent implements OnInit {
  //Model数据
  //todoList = []
  todoList = ['开会', '上课', '培训']
  userInput = ''  //双向数据绑定到input

  doAdd(){
    //console.log(this.userInput)
    //在数组尾部添加新的元素
    this.todoList.push(this.userInput)
    //清空当前的用户输入
    this.userInput = ''
  }

  doDelete(index){
    //从数组的指定下标处删除一个元素
    this.todoList.splice(index, 1)
  }

  constructor() { 
  }

  ngOnInit() {
  }

}
