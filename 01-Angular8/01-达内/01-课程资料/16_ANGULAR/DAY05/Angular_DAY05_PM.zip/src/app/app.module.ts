import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Myc01ParentBlogComponent } from './myc01-parent-blog/myc01-parent-blog.component';
import { Myc02Child1ModifyComponent } from './myc02-child1-modify/myc02-child1-modify.component';
import { Myc03Child2PhotoComponent } from './myc03-child2-photo/myc03-child2-photo.component';
import { FormsModule } from '@angular/forms';
import { IndexComponent } from './index/index.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { UserCenterComponent } from './user-center/user-center.component'
import { RouterModule } from '@angular/router';
import { NotFoundComponent } from './not-found/not-found.component';

//声明路由词典——路由地址和路由组件的对应集合
let routes = [
  // {path:'', component:IndexComponent},
  {path:'', redirectTo: 'index', pathMatch:'full'},//重定向需要指定“路由地址匹配方式”为“完全匹配”
  {path:'index', component:IndexComponent},
  {path:'plist', component:ProductListComponent},
  {path:'pdetail/:lid', component:ProductDetailComponent},
  {path:'ucenter', component:UserCenterComponent},
  // **地址匹配任意格式的地址
  {path:'**', component: NotFoundComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    Myc01ParentBlogComponent,
    Myc02Child1ModifyComponent,
    Myc03Child2PhotoComponent,
    IndexComponent,
    ProductListComponent,
    ProductDetailComponent,
    UserCenterComponent,
    NotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    //导入路由模块，并注册路由词典，用于根模块中
    RouterModule.forRoot(routes)  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
