import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-myc02-child1-modify',
  templateUrl: './myc02-child1-modify.component.html',
  styleUrls: ['./myc02-child1-modify.component.css']
})
export class Myc02Child1ModifyComponent {
  private userInput:string = null;
  //userInput

  //事件发射器
  @Output()  //输出型属性，可以向父组件输出数据
  private cryEvent = new EventEmitter()

  doModify(){ 
    //子组件将要传递给父组件的数据
    //console.log(this.userInput)  
    //子组件此时想发射数据给父组件
    this.cryEvent.emit( this.userInput )
  }




  constructor() { }

  ngOnInit() {
  }

}
