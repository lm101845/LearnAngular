import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-myc03-child2-photo',
  templateUrl: './myc03-child2-photo.component.html',
  styleUrls: ['./myc03-child2-photo.component.css']
})
export class Myc03Child2PhotoComponent implements OnInit {
  //普通属性不能被父组件传值
  //private child2Name:string = null
  
  //输入型属性：父组件可以利用这种属性传值进来
  @Input()
  private child2Name:string = null

  constructor() { }

  ngOnInit() {
  }

}
