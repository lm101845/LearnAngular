import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-myc01-parent-blog',
  templateUrl: './myc01-parent-blog.component.html',
  styleUrls: ['./myc01-parent-blog.component.css']
})
export class Myc01ParentBlogComponent implements OnInit {
  private userName:string = '文艺小青年'
  //userName = '苍茫大地'

  //处理子组件的“cryEvent”
  doCry( e ){
    console.log('Parent.doCry():')
    console.log(e)  //自定义事件发射来的数据
    this.userName = e  
  }

  //使用ViewChild装饰器关联“视图子组件”
  @ViewChild('c0', {static: true})
  private child0;
  @ViewChild('c1', {static: true})
  private child1;
  @ViewChild('c2', {static: true})
  private child2;
  //输出父组件内部的有识别符的子组件
  print(){
    console.log(this.child0)
    console.log(this.child1)
    console.log(this.child2)
  }


  constructor() { }

  ngOnInit() {
  }

}
